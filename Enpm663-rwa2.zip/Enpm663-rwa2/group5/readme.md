
# RWA 1

Contains ENPM663 Group 5 submission for RWA 1.


## System Requirements

- Ubuntu 20.04
- ROS2 - Galactic Geochelone
- Gazebo


## Build and Compile instructions

Setup ARIAC environment and Group5 codebase

```
    cd "your_colcon_workspace"/src
    git clone https://github.com/usnistgov/ARIAC.git
    git clone git@github.com:Shubhamtakbhate1998/Enpm663.git
    cd ..
    colcon build
    source "your_colcon_workspace"/install/setup.bash
```

## Running Task Scripts

Start the ARIAC environment

```
  ros2 launch ariac_gazebo ariac.launch.py trial_name:=rwa1
```

Start the complete Launch File

```
  ros2 launch group5 rwa_1.launch.py 
```
